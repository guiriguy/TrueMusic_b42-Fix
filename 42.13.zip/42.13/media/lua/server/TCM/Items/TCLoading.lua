require "Items/SuburbsDistributions"
require "Items/ProceduralDistributions"
require "Vehicles/VehicleDistributions"
-- Thanks to Elf (https://steamcommunity.com/profiles/76561197967301191)

-- Tsarcraft.TCWalkman

table.insert(ProceduralDistributions["list"]["BreakRoomShelves"].items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["BreakRoomShelves"].items, 0.5);

table.insert(ProceduralDistributions["list"]["ClassroomShelves"].items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["ClassroomShelves"].items, 0.5);

table.insert(ProceduralDistributions["list"]["MusicStoreOthers"].items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["MusicStoreOthers"].items, 2);

table.insert(ProceduralDistributions["list"]["MusicStoreCDs"].items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["MusicStoreCDs"].items, 0.5);

table.insert(ProceduralDistributions["list"]["MusicStoreSpeaker"].items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["MusicStoreSpeaker"].items, 5);

table.insert(ProceduralDistributions["list"]["ClassroomDesk"].junk.items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["ClassroomDesk"].junk.items, 1);

table.insert(ProceduralDistributions["list"]["CrateElectronics"].items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["CrateElectronics"].items, 0.5);

table.insert(ProceduralDistributions["list"]["ElectronicStoreMisc"].items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["ElectronicStoreMisc"].items, 2);

table.insert(ProceduralDistributions["list"]["ElectronicStoreMusic"].items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["ElectronicStoreMusic"].items, 2);

table.insert(ProceduralDistributions["list"]["DaycareShelves"].junk.items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["DaycareShelves"].junk.items, 0.5);

table.insert(ProceduralDistributions["list"]["DeskGeneric"].junk.items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["DeskGeneric"].junk.items, 1);

table.insert(ProceduralDistributions["list"]["DresserGeneric"].junk.items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["DresserGeneric"].junk.items, 1);

table.insert(ProceduralDistributions["list"]["GigamartHouseElectronics"].items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["GigamartHouseElectronics"].items, 2);

table.insert(ProceduralDistributions["list"]["KitchenBook"].items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["KitchenBook"].items, 0.1);

table.insert(ProceduralDistributions["list"]["KitchenRandom"].items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["KitchenRandom"].items, 0.5);

table.insert(ProceduralDistributions["list"]["LivingRoomShelf"].items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["LivingRoomShelf"].items, 3);

table.insert(ProceduralDistributions["list"]["GarageTools"].items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["GarageTools"].items, 0.5);

table.insert(ProceduralDistributions["list"]["GarageMechanics"].items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["GarageMechanics"].items, 0.5);

table.insert(ProceduralDistributions["list"]["GarageCarpentry"].items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["GarageCarpentry"].items, 0.5);

table.insert(ProceduralDistributions["list"]["GarageMetalwork"].items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["GarageMetalwork"].items, 0.5);

table.insert(ProceduralDistributions["list"]["LivingRoomShelfNoTapes"].items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["LivingRoomShelfNoTapes"].items, 0.5);

table.insert(ProceduralDistributions["list"]["Locker"].items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["Locker"].items, 0.5);

table.insert(ProceduralDistributions["list"]["LockerClassy"].items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["LockerClassy"].items, 0.5);

table.insert(ProceduralDistributions["list"]["SchoolLockers"].items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["SchoolLockers"].items, 1);

table.insert(ProceduralDistributions["list"]["LibraryCounter"].junk.items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["LibraryCounter"].junk.items, 1);

table.insert(ProceduralDistributions["list"]["OfficeDesk"].junk.items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["OfficeDesk"].junk.items, 1);

table.insert(ProceduralDistributions["list"]["OfficeDeskHome"].junk.items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["OfficeDeskHome"].junk.items, 1);

table.insert(ProceduralDistributions["list"]["PoliceDesk"].junk.items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["PoliceDesk"].junk.items, 1);

table.insert(ProceduralDistributions["list"]["PrisonCellRandom"].junk.items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["PrisonCellRandom"].junk.items, 1);

table.insert(ProceduralDistributions["list"]["WardrobeChild"].junk.items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["WardrobeChild"].junk.items, 1);

table.insert(ProceduralDistributions["list"]["WardrobeRedneck"].junk.items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["WardrobeRedneck"].junk.items, 0.5);

table.insert(ProceduralDistributions["list"]["MechanicShelfElectric"].items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["MechanicShelfElectric"].items, 5);

table.insert(ProceduralDistributions["list"]["MechanicShelfElectric"].junk.items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["MechanicShelfElectric"].junk.items, 15);

table.insert(ProceduralDistributions["list"]["CrateCompactDiscs"].items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["CrateCompactDiscs"].items, 0.5);

table.insert(ProceduralDistributions["list"]["DeskGeneric"].items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["DeskGeneric"].items, 0.5);

table.insert(ProceduralDistributions["list"]["ShelfGeneric"].items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["ShelfGeneric"].items, 0.5);

table.insert(ProceduralDistributions["list"]["MusicStoreCases"].items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["MusicStoreCases"].items, 0.2);

table.insert(ProceduralDistributions["list"]["StoreCounterCleaning"].items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["StoreCounterCleaning"].items, 0.5);

table.insert(ProceduralDistributions["list"]["StoreCounterCleaning"].items, "Tsarcraft.TCWalkman");
table.insert(ProceduralDistributions["list"]["StoreCounterCleaning"].items, 0.5);

-- Tsarcraft.TCBoombox

table.insert(ProceduralDistributions["list"]["BedroomDresser"].junk.items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["BedroomDresser"].junk.items, 1);

table.insert(ProceduralDistributions["list"]["BreakRoomShelves"].items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["BreakRoomShelves"].items, 0.5);

table.insert(ProceduralDistributions["list"]["ClassroomShelves"].items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["ClassroomShelves"].items, 0.5);

table.insert(ProceduralDistributions["list"]["MusicStoreOthers"].items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["MusicStoreOthers"].items, 2);

table.insert(ProceduralDistributions["list"]["MusicStoreCDs"].items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["MusicStoreCDs"].items, 0.5);

table.insert(ProceduralDistributions["list"]["MusicStoreSpeaker"].items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["MusicStoreSpeaker"].items, 5);

table.insert(ProceduralDistributions["list"]["ClassroomDesk"].junk.items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["ClassroomDesk"].junk.items, 1);

table.insert(ProceduralDistributions["list"]["CrateElectronics"].items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["CrateElectronics"].items, 0.5);

table.insert(ProceduralDistributions["list"]["ElectronicStoreMisc"].items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["ElectronicStoreMisc"].items, 2);

table.insert(ProceduralDistributions["list"]["ElectronicStoreMusic"].items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["ElectronicStoreMusic"].items, 2);

table.insert(ProceduralDistributions["list"]["DaycareShelves"].junk.items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["DaycareShelves"].junk.items, 0.5);

table.insert(ProceduralDistributions["list"]["DeskGeneric"].junk.items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["DeskGeneric"].junk.items, 1);

table.insert(ProceduralDistributions["list"]["DresserGeneric"].junk.items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["DresserGeneric"].junk.items, 1);

table.insert(ProceduralDistributions["list"]["GigamartHouseElectronics"].items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["GigamartHouseElectronics"].items, 2);

table.insert(ProceduralDistributions["list"]["KitchenBook"].items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["KitchenBook"].items, 0.1);

table.insert(ProceduralDistributions["list"]["KitchenRandom"].items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["KitchenRandom"].items, 0.5);

table.insert(ProceduralDistributions["list"]["LivingRoomShelf"].items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["LivingRoomShelf"].items, 3);

table.insert(ProceduralDistributions["list"]["GarageTools"].items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["GarageTools"].items, 0.5);

table.insert(ProceduralDistributions["list"]["GarageMechanics"].items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["GarageMechanics"].items, 0.5);

table.insert(ProceduralDistributions["list"]["GarageCarpentry"].items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["GarageCarpentry"].items, 0.5);

table.insert(ProceduralDistributions["list"]["GarageMetalwork"].items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["GarageMetalwork"].items, 0.5);

table.insert(ProceduralDistributions["list"]["LivingRoomShelfNoTapes"].items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["LivingRoomShelfNoTapes"].items, 0.5);

table.insert(ProceduralDistributions["list"]["Locker"].items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["Locker"].items, 0.5);

table.insert(ProceduralDistributions["list"]["LockerClassy"].items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["LockerClassy"].items, 0.5);

table.insert(ProceduralDistributions["list"]["SchoolLockers"].items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["SchoolLockers"].items, 1);

table.insert(ProceduralDistributions["list"]["LibraryCounter"].junk.items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["LibraryCounter"].junk.items, 1);

table.insert(ProceduralDistributions["list"]["OfficeDesk"].junk.items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["OfficeDesk"].junk.items, 1);

table.insert(ProceduralDistributions["list"]["OfficeDeskHome"].junk.items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["OfficeDeskHome"].junk.items, 1);

table.insert(ProceduralDistributions["list"]["PoliceDesk"].junk.items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["PoliceDesk"].junk.items, 1);

table.insert(ProceduralDistributions["list"]["PrisonCellRandom"].junk.items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["PrisonCellRandom"].junk.items, 1);

table.insert(ProceduralDistributions["list"]["WardrobeChild"].junk.items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["WardrobeChild"].junk.items, 1);

table.insert(ProceduralDistributions["list"]["WardrobeRedneck"].junk.items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["WardrobeRedneck"].junk.items, 0.5);

table.insert(ProceduralDistributions["list"]["MechanicShelfElectric"].items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["MechanicShelfElectric"].items, 5);

table.insert(ProceduralDistributions["list"]["MechanicShelfElectric"].junk.items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["MechanicShelfElectric"].junk.items, 15);

table.insert(ProceduralDistributions["list"]["CrateCompactDiscs"].items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["CrateCompactDiscs"].items, 0.5);

table.insert(ProceduralDistributions["list"]["DeskGeneric"].items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["DeskGeneric"].items, 0.5);

table.insert(ProceduralDistributions["list"]["ShelfGeneric"].items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["ShelfGeneric"].items, 0.5);

table.insert(ProceduralDistributions["list"]["MusicStoreCases"].items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["MusicStoreCases"].items, 0.2);

table.insert(ProceduralDistributions["list"]["StoreCounterCleaning"].items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["StoreCounterCleaning"].items, 0.5);

table.insert(ProceduralDistributions["list"]["StoreCounterCleaning"].items, "Tsarcraft.TCBoombox");
table.insert(ProceduralDistributions["list"]["StoreCounterCleaning"].items, 0.5);

-- TCVinylplayer


table.insert(ProceduralDistributions["list"]["StoreCounterCleaning"].items, "Tsarcraft.TCVinylplayer");
table.insert(ProceduralDistributions["list"]["StoreCounterCleaning"].items, 0.5);

table.insert(ProceduralDistributions["list"]["StoreCounterCleaning"].items, "Tsarcraft.TCVinylplayer");
table.insert(ProceduralDistributions["list"]["StoreCounterCleaning"].items, 0.5);

table.insert(ProceduralDistributions["list"]["ElectronicStoreMusic"].items, "Tsarcraft.TCVinylplayer");
table.insert(ProceduralDistributions["list"]["ElectronicStoreMusic"].items, 2);

table.insert(ProceduralDistributions["list"]["ElectronicStoreMisc"].items, "Tsarcraft.TCVinylplayer");
table.insert(ProceduralDistributions["list"]["ElectronicStoreMisc"].items, 5);

table.insert(ProceduralDistributions["list"]["MusicStoreCases"].items, "Tsarcraft.TCVinylplayer");
table.insert(ProceduralDistributions["list"]["MusicStoreCases"].items, 2);

table.insert(ProceduralDistributions["list"]["ShelfGeneric"].items, "Tsarcraft.TCVinylplayer");
table.insert(ProceduralDistributions["list"]["ShelfGeneric"].items, 1);

table.insert(ProceduralDistributions["list"]["CrateCompactDiscs"].items, "Tsarcraft.TCVinylplayer");
table.insert(ProceduralDistributions["list"]["CrateCompactDiscs"].items, 2);

table.insert(ProceduralDistributions["list"]["DeskGeneric"].items, "Tsarcraft.TCVinylplayer");
table.insert(ProceduralDistributions["list"]["DeskGeneric"].items, 0.5);

table.insert(ProceduralDistributions["list"]["MechanicShelfElectric"].junk.items, "Tsarcraft.TCVinylplayer");
table.insert(ProceduralDistributions["list"]["MechanicShelfElectric"].junk.items, 15);

table.insert(ProceduralDistributions["list"]["MechanicShelfElectric"].items, "Tsarcraft.TCVinylplayer");
table.insert(ProceduralDistributions["list"]["MechanicShelfElectric"].items, 3);

table.insert(ProceduralDistributions["list"]["GarageTools"].items, "Tsarcraft.TCVinylplayer");
table.insert(ProceduralDistributions["list"]["GarageTools"].items, 0.5);

table.insert(ProceduralDistributions["list"]["GarageMechanics"].items, "Tsarcraft.TCVinylplayer");
table.insert(ProceduralDistributions["list"]["GarageMechanics"].items, 1);

table.insert(ProceduralDistributions["list"]["GarageCarpentry"].items, "Tsarcraft.TCVinylplayer");
table.insert(ProceduralDistributions["list"]["GarageCarpentry"].items, 1);

table.insert(ProceduralDistributions["list"]["GarageMetalwork"].items, "Tsarcraft.TCVinylplayer");
table.insert(ProceduralDistributions["list"]["GarageMetalwork"].items, 1);

table.insert(ProceduralDistributions["list"]["MusicStoreOthers"].items, "Tsarcraft.TCVinylplayer");
table.insert(ProceduralDistributions["list"]["MusicStoreOthers"].items, 1);

table.insert(ProceduralDistributions["list"]["MusicStoreCDs"].items, "Tsarcraft.TCVinylplayer");
table.insert(ProceduralDistributions["list"]["MusicStoreCDs"].items, 2);

table.insert(ProceduralDistributions["list"]["MusicStoreSpeaker"].items, "Tsarcraft.TCVinylplayer");
table.insert(ProceduralDistributions["list"]["MusicStoreSpeaker"].items, 2);

table.insert(ProceduralDistributions["list"]["CrateElectronics"].items, "Tsarcraft.TCVinylplayer");
table.insert(ProceduralDistributions["list"]["CrateElectronics"].items, 3);

table.insert(ProceduralDistributions["list"]["GigamartHouseElectronics"].items, "Tsarcraft.TCVinylplayer");
table.insert(ProceduralDistributions["list"]["GigamartHouseElectronics"].items, 2);

table.insert(ProceduralDistributions["list"]["LivingRoomShelf"].items, "Tsarcraft.TCVinylplayer");
table.insert(ProceduralDistributions["list"]["LivingRoomShelf"].items, 0.5);

table.insert(ProceduralDistributions["list"]["LivingRoomShelfNoTapes"].items, "Tsarcraft.TCVinylplayer");
table.insert(ProceduralDistributions["list"]["LivingRoomShelfNoTapes"].items, 0.5);

table.insert(ProceduralDistributions["list"]["Locker"].items, "Tsarcraft.TCVinylplayer");
table.insert(ProceduralDistributions["list"]["Locker"].items, 0.5);

table.insert(ProceduralDistributions["list"]["OfficeDesk"].junk.items, "Tsarcraft.TCVinylplayer");
table.insert(ProceduralDistributions["list"]["OfficeDesk"].junk.items, 0.5);

table.insert(ProceduralDistributions["list"]["OfficeDeskHome"].junk.items, "Tsarcraft.TCVinylplayer");
table.insert(ProceduralDistributions["list"]["OfficeDeskHome"].junk.items, 0.5);

table.insert(ProceduralDistributions["list"]["PoliceDesk"].junk.items, "Tsarcraft.TCVinylplayer");
table.insert(ProceduralDistributions["list"]["PoliceDesk"].junk.items, 0.5);

table.insert(ProceduralDistributions["list"]["PrisonCellRandom"].junk.items, "Tsarcraft.TCVinylplayer");
table.insert(ProceduralDistributions["list"]["PrisonCellRandom"].junk.items, 0.5);
