require "Definitions/ContainerButtonIcons"

ContainerButtonIcons = ContainerButtonIcons or {}
ContainerButtonIcons.tcmusic = getTexture("media/ui/Container_Musictape.png")
